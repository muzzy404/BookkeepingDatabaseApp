create trigger BI_PROJECTS
  before insert
  on PROJECTS
  for each row
  begin   
  if :NEW."ID" is null then 
    select "PROJECTS_SEQ".nextval into :NEW."ID" from dual; 
  end if; 
end;
/

