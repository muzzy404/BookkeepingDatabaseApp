create trigger DEP_DELETE
  before delete
  on DEPARTMENTS
  for each row
  DECLARE
    prj_mentions NUMBER;
    emp_mentions NUMBER;
    pragma autonomous_transaction;
BEGIN
    SELECT COUNT(*) INTO prj_mentions 
    FROM PROJECTS
    WHERE DEPARTMENT_ID = :OLD.ID;

    SELECT COUNT(*) INTO emp_mentions 
    FROM DEPARTMENTS_EMPLOYEES
    WHERE DEPARTMENT_ID = :OLD.ID;

    IF (prj_mentions + emp_mentions) > 0 THEN
        RAISE_APPLICATION_ERROR(-20005,'can not delete department, using by others entities');
    END IF;
END;
/

