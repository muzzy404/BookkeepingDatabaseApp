create PROCEDURE same_prj_employees(first       IN  NUMBER,
                                               second      IN  NUMBER,
                                               p_recordset OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN p_recordset FOR
        SELECT PROJECTS.NAME
        FROM PROJECTS, DEPARTMENTS_EMPLOYEES
        WHERE PROJECTS.DEPARTMENT_ID = DEPARTMENTS_EMPLOYEES.DEPARTMENT_ID AND
             (DEPARTMENTS_EMPLOYEES.EMPLOYEE_ID = first OR
              DEPARTMENTS_EMPLOYEES.EMPLOYEE_ID = second)
        GROUP BY PROJECTS.NAME
        HAVING COUNT(DEPARTMENTS_EMPLOYEES.EMPLOYEE_ID) = 2;
END same_prj_employees;
/

