create trigger BI_DEPARTMENTS_EMPLOYEES
  before insert
  on DEPARTMENTS_EMPLOYEES
  for each row
  begin   
  if :NEW."ID" is null then 
    select "DEPARTMENTS_EMPLOYEES_SEQ".nextval into :NEW."ID" from dual; 
  end if; 
end;
/

