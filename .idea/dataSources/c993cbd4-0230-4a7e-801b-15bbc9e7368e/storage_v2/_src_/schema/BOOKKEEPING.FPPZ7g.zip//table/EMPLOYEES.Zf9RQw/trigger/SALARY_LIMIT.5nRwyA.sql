create trigger SALARY_LIMIT
  before insert
  on EMPLOYEES
  for each row
  DECLARE
    sal_lim NUMBER := 500000;
BEGIN
    IF :NEW."SALARY" > sal_lim THEN
        RAISE_APPLICATION_ERROR(-20001,'can not add row: salary of the employee exceeds the limit');
    END IF;
END;
/

