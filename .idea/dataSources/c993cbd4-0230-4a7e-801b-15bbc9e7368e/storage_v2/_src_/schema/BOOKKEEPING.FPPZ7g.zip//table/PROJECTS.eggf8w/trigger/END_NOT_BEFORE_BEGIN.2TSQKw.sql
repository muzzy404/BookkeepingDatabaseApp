create trigger END_NOT_BEFORE_BEGIN
  before insert or update
  on PROJECTS
  for each row
  BEGIN
    IF :NEW.DATE_END < :NEW.DATE_BEG
    THEN
        RAISE_APPLICATION_ERROR(-20003,'date of end can not be less then date of begin');
    END IF;
END;
/

