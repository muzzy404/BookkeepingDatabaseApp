create PROCEDURE longest_prj(dep  IN  NUMBER,
                                        time OUT NUMBER,
                                        prj  OUT VARCHAR2)
AS
BEGIN
    SELECT * INTO prj, time
    FROM (SELECT PROJECTS.NAME,
                 ROUND(MONTHS_BETWEEN(TO_DATE(PROJECTS.DATE_END, 'MM/DD/YYYY'),
                                      TO_DATE(PROJECTS.DATE_BEG, 'MM/DD/YYYY')), 2) AS "PERIOD"
          FROM PROJECTS
          WHERE PROJECTS.DEPARTMENT_ID = dep
          ORDER BY PERIOD DESC) A
    WHERE ROWNUM = 1;
END longest_prj;
/

