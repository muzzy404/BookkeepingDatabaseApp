create trigger BI_EMPLOYEES
  before insert
  on EMPLOYEES
  for each row
  begin   
  if :NEW."ID" is null then 
    select "EMPLOYEES_SEQ".nextval into :NEW."ID" from dual; 
  end if; 
end;
/

