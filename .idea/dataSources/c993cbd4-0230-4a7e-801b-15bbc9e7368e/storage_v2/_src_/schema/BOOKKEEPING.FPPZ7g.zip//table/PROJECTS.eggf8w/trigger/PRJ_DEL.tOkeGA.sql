create trigger PRJ_DEL
  before delete
  on PROJECTS
  for each row
  DECLARE
    end_plan DATE;
    end_real DATE;
    now_date DATE;
    pragma autonomous_transaction;
BEGIN
    SELECT TO_CHAR (SYSDATE, 'MM/DD/YYYY') INTO now_date
    FROM DUAL;

    SELECT DATE_END INTO end_plan
    FROM PROJECTS
    WHERE ID = :OLD.ID;

    SELECT DATE_END_REAL INTO end_real
    FROM PROJECTS
    WHERE ID = :OLD.ID;

    IF end_real IS NULL THEN
        RAISE_APPLICATION_ERROR(-20006,'the project is not yet complete, real end date is null');
    END IF;

    IF end_real > now_date THEN
        RAISE_APPLICATION_ERROR(-20006,'the project is not yet complete, real date has not yet come');
    END IF;

    IF end_plan > now_date THEN
        RAISE_APPLICATION_ERROR(-20006,'the project is not yet complete, plan date has not yet come');
    END IF;
END;
/

