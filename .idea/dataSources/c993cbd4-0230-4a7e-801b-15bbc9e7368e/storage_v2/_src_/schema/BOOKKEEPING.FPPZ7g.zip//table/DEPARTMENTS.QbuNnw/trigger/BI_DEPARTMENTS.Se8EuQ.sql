create trigger BI_DEPARTMENTS
  before insert
  on DEPARTMENTS
  for each row
  begin   
  if :NEW."ID" is null then 
    select "DEPARTMENTS_SEQ".nextval into :NEW."ID" from dual; 
  end if; 
end;
/

