create trigger ONLY_ONE_PRJ_TO_DEP
  before insert or update
  on PROJECTS
  for each row
  DECLARE
    pragma autonomous_transaction;
    prjs_num NUMBER;
BEGIN
    SELECT COUNT(*) INTO prjs_num
        FROM PROJECTS
        WHERE PROJECTS.DEPARTMENT_ID = :NEW."DEPARTMENT_ID";
    IF prjs_num > 0
    THEN
        RAISE_APPLICATION_ERROR(-20003,'department can not take part in a new project');
    END IF;
END;
/

