create trigger DEP_EMP_DELETE
  before delete
  on EMPLOYEES
  for each row
  DECLARE
    deps NUMBER;
    pragma autonomous_transaction;
BEGIN
    SELECT COUNT(*) INTO deps
    FROM DEPARTMENTS_EMPLOYEES
    WHERE DEPARTMENTS_EMPLOYEES.EMPLOYEE_ID = :OLD.ID;

    IF deps > 0 THEN
        RAISE_APPLICATION_ERROR(-20004,'person is a department employee');
    END IF;
END;
/

