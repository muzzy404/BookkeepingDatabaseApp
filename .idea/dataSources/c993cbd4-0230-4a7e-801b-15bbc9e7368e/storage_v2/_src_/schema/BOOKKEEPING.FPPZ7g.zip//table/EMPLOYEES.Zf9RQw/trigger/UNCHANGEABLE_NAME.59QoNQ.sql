create trigger UNCHANGEABLE_NAME
  before update
  on EMPLOYEES
  for each row
  BEGIN
    IF :NEW."FIRST_NAME" IS NOT NULL THEN
        RAISE_APPLICATION_ERROR(-20002,'can not update names of employees');
    END IF;
END;
/

