create PROCEDURE profits_sum(date_beg IN  DATE,
                                        profit   OUT NUMBER)
AS
    res_rc SYS_REFCURSOR;

    prj_name     VARCHAR2(200);
    prj_date_end DATE;
    prj_profit   NUMBER;
    date_now     DATE;
BEGIN
    profit := 0;

    SELECT TO_CHAR(SYSDATE, 'MM/DD/YYYY') INTO date_now FROM DUAL;

    OPEN res_rc FOR
    SELECT A.NAME,
           A.DATE_END_REAL,
           ROUND(B.COST - B.ALLSALARY * A.PERIOD, 2) AS "PROFIT"
    FROM (SELECT PROJECTS.NAME, PROJECTS.DATE_END_REAL,
                 MONTHS_BETWEEN (TO_DATE(PROJECTS.DATE_END, 'MM/DD/YYYY'),
                                 TO_DATE(PROJECTS.DATE_BEG, 'MM/DD/YYYY')) AS "PERIOD" FROM PROJECTS) A
    INNER JOIN (
    SELECT P.NAME,
           P.COST,
           SUM(E.SALARY) AS "ALLSALARY"
    FROM PROJECTS P INNER JOIN DEPARTMENTS_EMPLOYEES E_D
    ON P.DEPARTMENT_ID = E_D.DEPARTMENT_ID
         INNER JOIN EMPLOYEES E
    ON E_D.EMPLOYEE_ID = E.ID
    GROUP BY P.NAME, P.COST) B
    ON A.NAME = B.NAME;

    LOOP
        FETCH res_rc INTO prj_name, prj_date_end, prj_profit;
        EXIT WHEN res_rc%notfound;
        IF (prj_date_end < date_now AND prj_date_end > date_beg) THEN
            profit := profit + prj_profit;
        END IF;
    END LOOP;    

    CLOSE res_rc;
END profits_sum;
/

